/* tslint:disable */
/* eslint-disable */

/**
 * A response returned across the wasm boundary.
 *
 * Headers are a flat `[name, value, name, value, ...]` array. Repeated header names remain
 * repeated, which lets a Node host reconstruct the original HTTP response without joining them.
 */
export class LwsResponse {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Complete response bytes.
     */
    readonly body: Uint8Array;
    /**
     * Flat name/value response-header pairs.
     */
    readonly headers: string[];
    /**
     * Numeric HTTP status code.
     */
    readonly status: number;
}

/**
 * A single-threaded, in-memory Solid/LDP request handler.
 *
 * The owner WebID passed to the constructor receives Read, Write, and Control on the storage
 * root and descendants. That is initial provisioning, not OIDC verification. The JavaScript
 * host verifies every real credential and passes the resulting WebID to `handleRequest`.
 */
export class SolidServer {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Drive one request through the real axum router and its LDP, WAC, CORS, and body-limit
     * layers.
     *
     * `headers` is a flat `[name, value, ...]` array and must contain an even number of strings.
     * `authenticated_webid` is trusted only because the JavaScript host is responsible for OIDC;
     * omit it for an anonymous request. The returned Promise needs no Tokio reactor.
     */
    handleRequest(method: string, path: string, headers: string[], body: Uint8Array, authenticated_webid?: string | null): Promise<LwsResponse>;
    /**
     * Create an isolated in-memory pod and provision its owner ACL.
     */
    constructor(base_url: string, owner_webid: string);
}

/**
 * Called once by the wasm-bindgen runtime when the module is first loaded.
 *
 * Installs a panic hook that writes the panic message to `console.error` before the
 * `unreachable` trap propagates to the host as a `WebAssembly.RuntimeError`. The hook
 * is idempotent — safe to call from any context, and a no-op if already installed.
 */
export function lws_init(): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly lws_init: () => void;
    readonly __wbg_lwsresponse_free: (a: number, b: number) => void;
    readonly lwsresponse_status: (a: number) => number;
    readonly lwsresponse_headers: (a: number) => [number, number];
    readonly lwsresponse_body: (a: number) => [number, number];
    readonly __wbg_solidserver_free: (a: number, b: number) => void;
    readonly solidserver_new: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly solidserver_handleRequest: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number) => any;
    readonly wasm_bindgen__convert__closures_____invoke__h39844d7cc2e33618: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h079b372201195c9a: (a: number, b: number, c: any, d: any) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
