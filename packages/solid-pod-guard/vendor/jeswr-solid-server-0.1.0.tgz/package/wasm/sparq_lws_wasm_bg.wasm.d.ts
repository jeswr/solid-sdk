/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const lws_init: () => void;
export const __wbg_lwsresponse_free: (a: number, b: number) => void;
export const lwsresponse_status: (a: number) => number;
export const lwsresponse_headers: (a: number) => [number, number];
export const lwsresponse_body: (a: number) => [number, number];
export const __wbg_solidserver_free: (a: number, b: number) => void;
export const solidserver_new: (a: number, b: number, c: number, d: number) => [number, number, number];
export const solidserver_handleRequest: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number) => any;
export const wasm_bindgen__convert__closures_____invoke__h39844d7cc2e33618: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen__convert__closures_____invoke__h079b372201195c9a: (a: number, b: number, c: any, d: any) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_destroy_closure: (a: number, b: number) => void;
export const __externref_drop_slice: (a: number, b: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
